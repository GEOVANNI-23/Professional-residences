

# primera-plataformawebRH
El usuario es: admnistrador,
La contraseña es: 12345.


![proyecto-2](https://user-images.githubusercontent.com/56574048/115072528-56f77e80-9ebd-11eb-8f4c-8f2f59ad65b3.png)
