<?php

$opciones=$_POST['opciones'];

if($opciones == 1){
  echo "elegiste la primera opcion";
}

if($opciones == 2){
  echo "elegiste la segunda opcion";
}

if($opciones == 3){
  echo "elegiste la tercera opcion";
}
if($opciones == 4){
  echo "elegiste la tercera opcion";
}
if($opciones == 5){
  echo "elegiste la tercera opcion";
}
if($opciones == 6){
  echo "elegiste la tercera opcion";
}

 ?>
